package com.project.demo.json.createAst;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.project.demo.json.Data_Saved.AnnotationCorrespondingMethod_Node;
import com.project.demo.json.Data_Saved.MethodCallOtherMethods_Node;

import java.util.ArrayList;
import java.util.List;

import static com.project.demo.json.RunParser_search.VisitorFilesToGetData.*;

public class annotationAST {

    MethodCallOtherMethods_Node to_find = new MethodCallOtherMethods_Node(null,null,null,null);
    ArrayList<String> CallMethods = new ArrayList<>();

    int space_count=11; //空格數，看起來有一層一層的
    int method_index , child_index ; //用來記錄method、child所在的index
    ArrayList<MethodCallOtherMethods_Node> list_for_child = new ArrayList<>(); //存child_method

    public void find_annotation_AST() throws JsonProcessingException {

        for(int i=0;i<annotation_Node.size();i++){

            System.out.println(annotation_Node.get(i).getAnnotations()+"---"+annotation_Node.get(i).getMethodName()); //印接口、接口底下的method
            method_index = to_find.find_index(methodCall_Node,annotation_Node.get(i).getMethodName()); //找接口底下的method在MethodCallOtherMethods_Node裡的index
            //判斷接口底下的method所呼叫的method是否為使用者自定義
            CallMethods = methodCall_Node.get(method_index).getCallMethods_str();
            for(String temp_CallMethods : CallMethods) {
                for (int j = 0; j < 8; j++) {
                    System.out.print(" ");
                }

                // 輸出
                System.out.print("|");
                System.out.println("___" + temp_CallMethods + "     ");
                String[] arrSplit = temp_CallMethods.split(":");

                find_all_called(arrSplit[1],methodCall_Node); //繼續往下一層找

                // add child to child_methods
                child_index = to_find.find_index(methodCall_Node,arrSplit[1]);
                MethodCallOtherMethods_Node ChildNeedToAdd = methodCall_Node.get(child_index); // ChildNeedToAdd存子孫的node
                list_for_child.add(ChildNeedToAdd); //把Child_node加進list_for_child這個arraylist裡

            }
            annotation_Node.get(i).setChild_methods((ArrayList<MethodCallOtherMethods_Node>) list_for_child.clone());

//            AnnotationCorrespondingMethod_Node temp = new AnnotationCorrespondingMethod_Node(ChildWillAddTo_annotation.getAnnotations(), ChildWillAddTo_annotation.getMethodName(), ChildWillAddTo_annotation.getClassName(), ChildWillAddTo_annotation.getEndpoint(), list_for_child);

            ASTBuild.add(annotation_Node.get(i));

            // 檢查存到的child_methods有沒有正確
//            System.out.print(ChildWillAddTo_annotation.getMethodName()+"-----"); //印現在的method name
//            for(MethodCallOtherMethods_Node check : annotation_Node.get(i).getChild_methods()){
//                System.out.print(check.getMethodName()+"、");
//            }
//            System.out.println();
            // 清空list，不然會存到之前的
            list_for_child.clear();
        }

    }

    public String find_all_called(String method,List<MethodCallOtherMethods_Node> node_for_method) throws JsonProcessingException {
        MethodCallOtherMethods_Node ChildWillAddTo;
        MethodCallOtherMethods_Node ChildNeedToAdd = null;
        String[] arrSplit = new String[1000];

        method_index = to_find.find_index(methodCall_Node, method); //找method所在的index
        CallMethods = node_for_method.get(method_index).getCallMethods_str();

        // 如果 method 沒有呼叫別的 method 了就離開
        if (CallMethods.size() == 0) {
            return null;
        }
        //如果有就遞迴的一直找下去，直到沒有
        else {
            ChildWillAddTo = methodCall_Node.get(method_index); // ChildWillAddTo存父親的node
            for (String temp_CallMethods : CallMethods) {
                for (int j = 0; j < space_count; j++) {
                    System.out.print(" ");
                }
                System.out.print("|");
                System.out.println("___" + temp_CallMethods + "     ");

                arrSplit = temp_CallMethods.split(":");

                space_count += 5; //控制層數

                find_all_called(arrSplit[1], node_for_method); //繼續往下一層找

                // add child to child_method
                child_index = to_find.find_index(methodCall_Node, arrSplit[1]);
                ChildNeedToAdd = methodCall_Node.get(child_index); // ChildNeedToAdd存子孫的node
                list_for_child.add(ChildNeedToAdd); //把Child_node加進list_for_child這個arraylist

                space_count -= 5;
            }
            ChildWillAddTo.setChild_methods((ArrayList<MethodCallOtherMethods_Node>) list_for_child.clone()); //把list_for_child存到的內容加進去父親的Child_methods裡面

            // 檢查存到的child_methods有沒有正確
            System.out.print(ChildWillAddTo.getMethodName() + "-----");
            for (MethodCallOtherMethods_Node check : ChildWillAddTo.getChild_methods()) {
                System.out.print(check.getMethodName() + "、");
            }
            System.out.println();


            list_for_child.clear();
        }
        return "null";
    }

    public String find_ast(AnnotationCorrespondingMethod_Node node_input) {
        for(MethodCallOtherMethods_Node temp_CallMethods : node_input.getChild_methods()) {
            for (int j = 0; j < space; j++) {
                System.out.print(" ");
            }
            //輸出
            System.out.print("|");
            if(temp_CallMethods.getChild_methods()!=null){
                System.out.print("___" + temp_CallMethods.getMethodName() + "     ");
                System.out.println(temp_CallMethods.getChild_methods().size());
            }
            else{
                System.out.println("___" + temp_CallMethods.getMethodName() + "     ");
            }
            space += 5;
            if(temp_CallMethods.getChild_methods()!=null){
                print_ast(temp_CallMethods.getChild_methods());
            }
            space -= 5;
        }
        System.out.println();
        space=11;
        return "null";
    }

    public String print_ast(List<MethodCallOtherMethods_Node> node_for_method) {

        for (int i_index=0;i_index<node_for_method.size();i_index++) {
            for (int j_index = 0; j_index < space; j_index++) {
                System.out.print(" ");
            }
            System.out.print("|");
            if(node_for_method.get(i_index).getChild_methods()!=null){
                System.out.println("___" + node_for_method.get(i_index).getMethodName() + "     "+node_for_method.get(i_index).getChild_methods().size());
            }
            else{
                System.out.println("___" + node_for_method.get(i_index).getMethodName() + "     ");
            }

            space += 5;   // 控制層數
            if(node_for_method.get(i_index).getChild_methods()!=null){
                print_ast(node_for_method.get(i_index).getChild_methods()); //繼續往下一層找
            }
            space -= 5;
        }
        return "null";
    }
}