package com.project.demo.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtils {
    public static void deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectory(file);
                }
            }
        }
        directory.delete();
    }
    public static void addJsonDirectory(String createPath){
        Path directoryPath = Paths.get(createPath);

        if (Files.exists(directoryPath)) {
            // 目錄已存在，執行相應處理
        } else {
            try {
                if (Files.isWritable(directoryPath.getParent())) {
                    Files.createDirectories(directoryPath);
                } else {
                    // 沒有寫入權限，處理相應錯誤
                }
            } catch (IOException e) {
                // 處理IO異常
            }
        }
    }
}