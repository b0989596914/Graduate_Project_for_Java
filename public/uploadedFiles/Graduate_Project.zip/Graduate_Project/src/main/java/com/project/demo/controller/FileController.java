package com.project.demo.controller;

import com.project.demo.Search_PomXml;
import com.project.demo.json.RunParser_search.VisitorFilesToGetData;
import com.project.demo.payload.UploadFileResponse;
import com.project.demo.service.FileStorageService;
import com.project.demo.util.FileUtils;
import com.project.demo.util.ZipUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@RestController
@RequestMapping("/")
@CrossOrigin  //解決跨域問題
public class FileController {

    private static final Logger logger = LoggerFactory.getLogger(FileController.class);
    public String thisTimeFileToJson;
    int flag = 0, success_unzip = -1, del_times = 0;     // flag -> 判斷有無找到 Spring Boot 的核心資料 ; have_file -> 預設有檔案進來
    String lastFileName = "";        // 記得上一次的檔案名稱

    @Value("${folder.unzip_path}")
    public String unzip_file_path;

    @Value("${folder.path}")
    public String uploads_path;

    @Value("${file.upload-dir}")
    public String zip_file_path;

    @Value("${folder.json_path}")
    public String json_file_path;

    @Autowired
    private FileStorageService fileStorageService;

    @PostMapping("/uploadFile")
    public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        success_unzip = -1; // 沒有上傳
        try {
            FileUtils.deleteDirectory(new File(uploads_path));
            Files.createDirectories(Path.of(zip_file_path));
//                Files.createDirectories(Path.of((json_file_path)));
            //            Files.createDirectories(Path.of(json_file_path));
        } catch (IOException e) {
            e.printStackTrace();
        }
//        if (FileSystemUtils.deleteRecursively(Path.of(uploads_path))){
//            Files.createDirectories(Path.of(zip_file_path));
//            Files.createDirectories(Path.of(json_file_path));
//
//        }

        String fileName = fileStorageService.storeFile(file);       // 儲存 zip 檔案

        thisTimeFileToJson = unzip_file_path + "/" + fileName.substring(0,fileName.lastIndexOf(".zip")) + "/";

        // 解壓缩 ZIP 文件
        String zipFilePath = Paths.get(zip_file_path).toAbsolutePath()  + "\\" + fileName;
        String destDirectory = String.valueOf(Paths.get(unzip_file_path).toAbsolutePath());
        try {
            ZipUtils.unzip(zipFilePath, destDirectory);
            success_unzip = 1;  // 解壓縮成功
            System.out.println("ZIP and UNZIP file extracted successfully.");
        } catch (IOException e) {
            success_unzip = 0; // 解壓縮失敗
            System.err.println("Error extracting ZIP file: " + e.getMessage());
        }

        // Web MVC 框架的 URI builder
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();

        return new UploadFileResponse(fileName, fileDownloadUri, file.getContentType(), file.getSize());
    }

    @GetMapping("/downloadFile/{fileName:.+}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // Load file as Resource
        Resource resource = fileStorageService.loadFileAsResource(fileName);

        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            logger.info("Could not determine file type.");
        }

        // Fallback to the default content type if type could not be determined
        if(contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    @Configuration
    class WebConfig implements WebMvcConfigurer {
        @Value("${spring.thymeleaf.prefix}")
        public String origin_path;

        @Override   // 覆寫了父類別的方法
        public void addResourceHandlers(ResourceHandlerRegistry registry) {
            // 在 "/home/file/**" 前端 URL 訪問路徑，后面 file : xxxx 為本地資料夾映射
            registry.addResourceHandler("/home/**").addResourceLocations(origin_path);
            WebMvcConfigurer.super.addResourceHandlers(registry);
        }
    }

    @GetMapping("/checkSpringBoot")
    public Object checkSpringBoot() {
        // 抓解壓縮檔案的資料夾路徑
        Path absPath = Paths.get(new StringBuilder().append(thisTimeFileToJson).append("/").append("pom.xml").toString()).toAbsolutePath();
        System.out.println(absPath);

        // 判斷Springboot專案
        flag = Search_PomXml.FindSpring(absPath.toString());

        Map<String, Object> result = new HashMap<>();
        // 資料處理
        result.put("isSuccess",success_unzip);
        result.put("flag", flag);
        return result;
    }

    @GetMapping("/deleteFile")
    public Object deleteFile() throws IOException {
        int del_flag = 0;
        if (FileSystemUtils.deleteRecursively(Path.of(uploads_path))){
            Files.createDirectories(Path.of(zip_file_path));
            Files.createDirectories(Path.of(json_file_path));

            del_flag = 1;
            del_times += 1;
        }
        Map<String, Object> ans = new HashMap<>();
        ans.put("delete_flag", del_flag);       // 是否成功刪除
        ans.put("delete_times", del_times);     // 刪除次數

        return ans;
    }

    @GetMapping("/readJson")
    public void readJson() throws IOException {
        try {
            VisitorFilesToGetData nowGetData = new VisitorFilesToGetData();   // 資料初始化

            FileUtils.addJsonDirectory(((json_file_path)));
//        System.out.println(thisTimeFileToJson);
            File file = new File(thisTimeFileToJson);

            nowGetData.GoInFolder(file);
            nowGetData.Collating_Data();   // 整理資料 -> 去除


            String jsonFile_str = VisitorFilesToGetData.Data_Printer(json_file_path);


            String filePath = json_file_path + "/AST_output.json"; // 替換為您的檔案絕對路徑

            File getJF = new File(String.valueOf(Paths.get(filePath).toAbsolutePath()));
            InputStream inputStream = new FileInputStream(getJF);

//            byte[] fileContent = inputStream.readAllBytes();
//            inputStream.close();
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.setContentDispositionFormData("attachment", "AST_output.json");
//
//            return ResponseEntity.ok()
//                    .headers(headers)
//                    .body(fileContent);
        }catch (IOException e) {
            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
