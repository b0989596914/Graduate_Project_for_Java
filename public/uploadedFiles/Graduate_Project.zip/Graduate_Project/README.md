# Graduate_Project
with todo list in project


## 網頁 zip 檔案放置於[web screen.zip](https://github.com/b0989596914/Graduate_Project/files/11811664/web.screen.zip)


* 下載之後請先解壓縮，再將資料夾 "web screen" 放入 C 槽中即可

## 網頁刪除按鍵

點擊後可以直接刪除 uploads 資料夾，不用重新執行後端程式碼
